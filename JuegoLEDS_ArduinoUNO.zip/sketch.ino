const int LED_PINS[] = {2, 3, 4, 5, 6, 7};  
const int NUM_LEDS = 6;
const int BOTON_PIN = 8;

int patronActual = 0;
const int NUM_PATRONES = 5;

int estadoBoton = LOW;
int estadoAnterior = LOW;
unsigned long tiempoUltimoDebounce = 0;
const unsigned long DELAY_DEBOUNCE = 50;


void setup() {
  for (int i = 0; i < NUM_LEDS; i++) {
    pinMode(LED_PINS[i], OUTPUT);
  }
  pinMode(BOTON_PIN, INPUT);  
  randomSeed(analogRead(A0));
}

void loop() {
  leerBoton();

  switch (patronActual) {
    case 0: patronSecuencia();   break;
    case 1: patronPersecucion(); break;
    case 2: patronParpadeo();    break;
    case 3: patronAleatorio();   break;
    case 4: patronOnda();        break;
  }
}

void leerBoton() {
  int lectura = digitalRead(BOTON_PIN);

  if (lectura != estadoAnterior) {
    tiempoUltimoDebounce = millis();
  }

  if ((millis() - tiempoUltimoDebounce) > DELAY_DEBOUNCE) {
    if (lectura != estadoBoton) {
      estadoBoton = lectura;
      if (estadoBoton == HIGH) {
        patronActual = (patronActual + 1) % NUM_PATRONES; 
        apagarTodos();
      }
    }
  }
  estadoAnterior = lectura;
}

void apagarTodos() {
  for (int i = 0; i < NUM_LEDS; i++) {
    digitalWrite(LED_PINS[i], LOW);
  }
}

void encenderTodos() {
  for (int i = 0; i < NUM_LEDS; i++) {
    digitalWrite(LED_PINS[i], HIGH);
  }
}

void patronSecuencia() {
  for (int i = 0; i < NUM_LEDS; i++) {
    leerBoton();
    digitalWrite(LED_PINS[i], HIGH);
    delay(150);
    digitalWrite(LED_PINS[i], LOW);
  }
}

void patronPersecucion() {

  for (int i = 0; i < NUM_LEDS; i++) {
    leerBoton();
    apagarTodos();
    digitalWrite(LED_PINS[i], HIGH);
    delay(120);
  }
  for (int i = NUM_LEDS - 2; i > 0; i--) {
    leerBoton();
    apagarTodos();
    digitalWrite(LED_PINS[i], HIGH);
    delay(120);
  }
}

void patronParpadeo() {
  encenderTodos();
  delay(300);
  apagarTodos();
  delay(300);
}

void patronAleatorio() {
  leerBoton();
  apagarTodos();
  int led = random(0, NUM_LEDS);
  digitalWrite(LED_PINS[led], HIGH);
  delay(200);
}

void patronOnda() {
  for (int i = 0; i < NUM_LEDS; i++) {
    leerBoton();
    apagarTodos();
    for (int j = 0; j <= i; j++) {
      digitalWrite(LED_PINS[j], HIGH);
    }
    delay(150);
  }
  for (int i = NUM_LEDS - 1; i >= 0; i--) {
    leerBoton();
    digitalWrite(LED_PINS[i], LOW);
    delay(150);
  }
}